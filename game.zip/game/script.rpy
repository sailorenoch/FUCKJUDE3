

define sounds = ['audio/A1.ogg', 'audio/A2.ogg', 'audio/A3.ogg', 'audio/A4.ogg', 'audio/A5.ogg', 'audio/B1.ogg', 'audio/B2.ogg', 'audio/B3.ogg', 'audio/B4.ogg', 'audio/B5.ogg']

init python:
    def type_sound(event, interact=True, **kwargs):
        if not interact:
            return

        if event == "show":
            renpy.sound.play(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))
            renpy.sound.queue(renpy.random.choice(sounds))



        elif event == "slow_done" or event == "end":
            renpy.sound.stop()



#######Characters#######


define e = Character("???",color="#ffffff",ctc="arrow", callback=type_sound)
define n = Character(ctc="arrow", ctc_position="nestled", callback=type_sound)
define j = Character ("Jude",color="#398000",ctc="arrow", ctc_position="nestled", image="jude", callback=type_sound, what_slow_cps=25 )
define lg = Character ("lesbian_gengar",color="#fc5ffc",ctc="arrow", image="est", callback=type_sound )
define bf = Character ("bluntfiend",color="#398000",ctc="arrow", ctc_position="nestled", image="jude", callback=type_sound )
define kk = Character("kkrule",ctc="arrow", ctc_position="nestled",color="#5f794a", callback=type_sound, image="kk")
define jj = Character("jockjamsvol6",ctc="arrow", ctc_position="nestled",color="#ac0000", callback=type_sound, image="jj")
define b = Character("bones",ctc="arrow", ctc_position="nestled",color="#e4e4e4", callback=type_sound)
define hp = Character("harmpit",ctc="arrow", ctc_position="nestled",color="#66867e", callback=type_sound, image="hp")
define pc = Character("polaricecraps",ctc="arrow", ctc_position="nestled",color="#0700d7", callback=type_sound, image="pic")
define gc = Character("gaycopmp4",ctc="arrow", ctc_position="nestled",color="#820543", callback=type_sound, image="as")
define dh = Character("hetcopogg",ctc="arrow", ctc_position="nestled",color="#82057c", callback=type_sound, image="dh")
define jjj = Character("JJ",ctc="arrow", ctc_position="nestled",color="#ac0000", callback=type_sound, what_slow_cps=60)
define jjjj = Character("JJ",ctc="arrow", ctc_position="nestled",color="#ac0000", callback=type_sound, image="jj", what_slow_cps=60)
define jf = Character ("Joseph the Flasher",color="#e1dda5",ctc="arrow", callback=type_sound )
define q = Character ("???",color="#ffffff",ctc="arrow", callback=type_sound )

#############
#images# 
###########

image arrow:
    "arrow.png"  
    alpha 1.0
    linear 0.8 alpha 0.0
    linear 0.8 alpha 1.0
    repeat


define good_points = 00

# The game starts here.

label start:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene bedn

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.



    # These display lines of dialogue.
    play music "relax.mp3"
    n "You were bundled deep under a bunker of blankets, but the cold still seeped into your bones."
    n "The biting chill coming from the freezing  winds whipping outside."
    n "Not that you’d know for sure. You hadn’t been outside. You hadn’t even opened the curtains."
    n "A thick layer of gunk clung heavily to your eyelashes as you finally focused on the clock."
    n "11 a.m. You were up early. Some mornings, you wished you hadn’t woken up at all, but today wasn’t one of those days."
    n "The space heater thrummed, pushing just enough warmth through your apartment to create the illusion of comfort."
    n "You were more alone than ever."
    j neutral "Fuck."
    n "You were a sad excuse for a faggot."
    n "A sad fag, if you will."
    n "You needed a smoke."
    n "Your legs felt like weights as they swung over the edge of the bed and hit the floor."
    n "You knew you’d been putting on weight, but you didn't want to check to see how much."
    n "Your eyes drifted around the dim bedroom."
    n "Where did you go first?"  

    menu:
        "Computer":
            $ good_points += 1
            n "Maybe you should talk to your friends."
            n "The strip of duct tape over your desktop camera had come loose. Without a second thought, you pressed it back into place."
            n "You jiggled the mouse, the screen illuminating against your face in that dark room."
            n "bluntfiend has entered the chat."
            kk neutral "theyve added homer simpson to fortnite"
            bf smile "They should add Gregg Turkington next."
            kk "huh?"
            bf neutral "nevermind."
            jj neutral "Hiii Jude. Check your steam account."
            bf "what, why?"
            bf concern "Why did you buy me a yaoi dating game?"
            jj "it says alot about society."
            lg neutral "we live in society rofl"
            b "How was that date?"
            bf neutral "Oh shit, yeah i went on a date."
            bf "I think I fucked it up by asking to meet up in the woods at midnight. There was a full moon that night."
            lg "but why?"
            hp neutral "wahy woild you do that??"
            lg "are you some kind of werewolf?"
            bf "I don't know, I read a book recently and I got really into the idea of making out in the woods."
            bf "So I waited for a bit before I heard someone yelling."
            kk "i watched a video on youtube about creatures in the mountains there mimicking human cries..."
            bf closed "No, I kinda wish it was that."
            bf neutral "I still don't know if this was my date, or just someone else in the woods that night."
            bf "Anyways, I saw him, and out of nowhere he started chasing me with a knife saying he was going to 'Joseph the kill me?'" 
            lg "youre sure your shit aint laced?"
            jj "No, this happens alot."
            jj "Especially in white people's visual novels."
            lg open "what the fuck is a white person visual novel?"
            jj "It's the ones that are all over itch.io." 
            jj "Go on itch.io right now and most visual novels fall under man with knife chasing you in the woods, the dating simulator."
            bf yell "Why would I want to go on a date where I get chased in the woods?"
            hp "well mayabe he thosught you wanted taht becuse uoy invsited him to thw woods in hei first place."
            lg neutral "i mean was he nice?"
            bf neutral "Yeah, I guess so. But I don't think things worked out between us. Which is fine but I hate the cycle of going out on hook-ups and fucking it up in someway."
            b "I don't think it was your fault your date chased you with a knife through the forest."
            bf "I think it's my fault for being a pervert and attracting evil people."
            n "polaricecraps has entered the chat."
            pc neutral "who's the pervert?"
            hp "jude i thionk"
            n "jockjamsvol6 left the chat."
            kk cry "PIC did you just join to stream snipe me :("
            pc "yes."
            kk neutral "can we at least do duos together?"
            pc "fine, but you suck ass at fortnite."
            kk "i won a tournament. i don't know what you're talking about."
            b "kkrule is correct, i can compare your two's statistics based on eliminations."
            pc "please don't"
            bf "i do feel so fucking alone, nobody wants a fat fag."
            b "Jude, please remember we implemented a no slurs rule."
            bf closed "???"
            bf concern "since when?"
            pc "since like last week, you even voted on it."
            bf yell "Why would i vote to lose my God given right to reclaim the word faggot?"
            b "Jude."
            bf neutral "1984 or whatever."
            n "You pushed from your desk and went searching for your weed stash. Your fingers traced around empty takeout containers and bottles of piss until they found the small bag."
            n "It was getting light."
            n "You rolled a blunt, it was too skinny."
            n "You knew you could do better than this."
            scene bedn






            
        "Bathroom":

            n "You started toward the bathroom. The door was gone. In its place hung a blanket, patterned with the image of a wolf. A pretty sick wolf at that."
            scene judebath with fade
            n "You really had to take a morning piss."
            n "Your own reflection caught your eye in the stained mirror." 
            n "Greasy hair stuck to your cheeks, and your acne had gotten worse."
            n "The hair on your arms stood up, almost like static electricity was buzzing around you."
            n "Esther said she felt static electricity in the air whenever she was around you."
            n "It was weird."
            n "You were almost infinitely powerful. Not much in the world could stand in your way."
            n "But you did."
            n "Why?"
            n "You still needed to piss."
            n "After pissing, you shuffled back to your desk and turned down the monitor's brightness, softening the harsh glow."
            scene bedn with fade

    
    play sound "notif.mp3"
    n "A chat notification chimed through your room."
    gc neutral "hey loser."
    gc "heard about your date"
    dh neutral "jj told us he was coming over, so you might want to throw on a shirt or something."
    gc "or you can surprise him"
    dh "don't do that."
    bf neutral "he is?"
    bf "i don't even think i have enough weed for the both of us."
    dh "anyways i think it's your chance to sort out your entire situationship with him."
    menu: 
        "JJ doesn't want me like that.":
            gc "I mean..."
            gc "I doubt he's coming over because he hates you, that's all i'll say lmfao"
            dh "do you want to go back on grindr and get chased in the woods again by jeff the killer???"
            bf "It was joseph the flasher."
            dh "exactly the point, you are only going to find off brand spirit halloween jeff the killers on there."
            bf "i think there's probably normal people on there, i think i just attract - i don't know how to put this nicely."
            dh "queers"
            dh "in like every sense of the word"
            gc "we wouldn't be your friends if that wasnt true."
            bf "Anyways, thanks. I'll see what he wants."

        "Thanks for the heads up.":
            $ good_points += 1
            gc "are you going to wear that button up you catholic school boy?"
            bf "No, but I'll wear that one clean shirt."
            dh "when was the last time you ran your laundry?"
            bf "I hardly ever even wear clothes."
            dh "tmi"
            bf "Not like that, but I don't see the need to wash my shit often if I don't even wear it."
            gc "please at least use dry shampoo."
            bf "I'm fine. JJ is a friend he's seen me at worse."
            bf "Thanks again."

    n "You grabbed a graphic tee from the pile on the floor and pulled it on without even looking at what it said."
    n "You ran your fingers through your greasy hair before reaching for the dry shampoo."
    n "It hadn't always been this color."
    n "A surge of electricity had permanently bleached your natural mousey brown hair."
    n "Your teeth were yellowed and bled at the gums, but at least you still had all of them. A mint should be enough."
    n "Nothing seemed to wash out the smell of weed anymore, it had soiled you and everything else."
    
    play sound "knock.mp3"
    pause 1.0
    scene bedn
    n "A knock at the door." 
    

    scene livingr with fade
    
    n "You were halfway to the door before you realized, you’d forgotten to put on pants."
    n "The door knob begun twisting on it's own."
    j opens "Just give me literally one minute, please."
    jjj "Okay! Your door is unlocked, by the way."
    j closed "I can see that. Lucky you."   
    n "You tugged on a pair of sweatpants." 
    j neutral "Okay."
    menu:
        "Open the door for him.":
            $ good_points += 1
            show jj
            n "JJ stood in the doorway, his arms loaded with grocery bags and a heavy looking pot."
            n "How did he even manage to turn the doorknob with his hands that full?"
            hide jj
            show jj smile
            jjj "It's cute when that Catholic schoolboy side of you comes out."
            j fluster "..."
            j "Sorry, it's a bit of a mess in here."
            jjj "No shit. Didn't expect anything different though."
            n "You took the heavy pot from him and turned to find a place for it, knocking over the empty bottles cluttering your table."
            hide jj smile
            show jj
        
        "Tell him it's unlocked.":
            show jj mad
            n "JJ stood in the doorway, his arms loaded with grocery bags and a heavy looking pot."
            n "He carried the remaining groceries inside, his usual prance replaced by stammering."
            j neutral "Hi."
            jjj "Hey. Where should I put all of this?"
            jjj "Your garbage is in the way."
            j neutral "You can just move it, I'll clean it up later."
            jjj "I can tell you do alot of cleaning."
            hide jj mad
            show jj
            
    j neutral "What did you bring?"
    jjj "Hot pot! I got some from the market and it was way too much for me."
    j "I never had hot pot."
    jjj "It's where you cook the food in the simmering broth while eating it."
    j "Sounds like alot of work."
    jjj "I mean so is cooking anything, I'll chop if you just plug the pot in."
    n "You took the pot to a place by the TV in the living room area. You got a picnic blanket underneath."
    j "This won't catch fire, right?"
    jjj "Depends, it shouldn't, but I think you must accidentally charge any sort of electrical device sometimes."
    j "Like when I exploded Esther's new phone."
    j "And her gameboy."
    hide jj 
    show jj stare
    jjj "And two of her record players."
    j "I promise it's not on purpose."
    hide jj stare
    show jj
    jjj "Well luckily I am not Esther."
    n "You chuckled at that."
    j smile "Did she not want to come over?"
    jjj "Oh well."
    jjj "I wanted this to be a practice date."
    j neutral "For?"
    jjj "For your hook-ups on grindr."
    j "Oh."
    j "I don't think things went that badly on my end."
    jjj "I guess getting chased in the woods isn't exactly your fault, but-"
    j "But?"
    hide jj
    show jj tsundere 
    jjj "But you need to up your game! You'll probably attract less serial killers."
    hide jj tsundere
    show jj mad
    j "So, this is a larp?"
    j "And any actual flirting you do is just part of the larp?"
    jjj "No, look just treat me like a date. Okay?"
    j "Okay."
    hide jj mad
    show jj
    jjj "Yay."
    n "Whatever, a date was a date."
    n "Your eyes tracked what he was wearing - a cropped sweater, horseshoe belt, two mismatched gloves, and baggy jeans sagging low enough to reveal a fresh tramp stamp above his ass."
    n "It was a heart that it swirled to resemble ornate lacework."
    n "If you got a tattoo it wouldn't be a heart."
    n "You'd get yourself a sword, one that was actually cool and manly. Not gay looking."
    j "Aren't you cold?"
    jjj "I've adapted."
    jjj "Nice shirt. You remember where you got it?"
    n "You looked down at what you were wearing."
    n "Printed in bold lettering it read 'The Legend of THE PLUG'."
    j "Uh. I think it just showed up."
    jjj "You're staring at my ass."
    
    menu:
        "Compliment his ass.":
            $ good_points += 1
            j fluster "If a monk saw that ass, he would spend the rest of his life writing poetry in filigree about it."
            hide jj
            show jj laugh
            n "JJ let out a loud laugh."
            jjj "How many times have you used that one?"
            j "Now, three."
            jjj "And how many times did it work?"
            j "I'd say three."
            hide jj laugh
            show jj
        
        "Compliment his personality.":
            j "Uh."
            j "Anyone tell you that you light up a room?"
            jjj "And where's this coming from?"
            n "You rolled your shoulders back in a shrug."
            n "You weren't good at this."
            n "JJ let out a soft chuckle."

    
    n "JJ unpacked the vegetables and broth bases, then began dumping them into the boiling pot, giving the occasional stir."
    n "You clicked on the TV while JJ stretched out on the floor, lying on his stomach."
    hide jj 
    scene jjyay
    j "So I just cook the meat in the soup?"
    jjj "Hrmmm..."
    jjj "Since when did that one billionaire launch rockets like right next your apartment?"
    j concern "Huh?"
    j "Never, I thought that shit was in California or Texas."
    jjj "Kinda sus when you think about."
    j "I've been noticing some oddities, but I don't think it's related."
    jjj "You should probably take out that sliced beef."
    j yell "Fuck!"
    n "You dropped the chopsticks and the beef into the soup."
    n "Hot soup splashed across your shirt, leaving a stain."
    n "JJ fished them out with a steadiness you could never manage yourself."
    n "You nibbled on the chewy meat, you wondered if you could just eat raw meat sometimes, it would be easier."
    n "JJ dabbed at the stain on your chest with a cloth."
    n "He used it as an excuse to let his hand linger for a bit too long."
    n "He leaned back with a smirk, dipping his own shrimp into the pot."
    n "You never liked eating as a date, it always felt like you were being mocked."
    n "JJ seemed oblivious to your simmering insecurities."
    n "Suddenly, he bit the head off a shrimp and tossed the rest into his mouth, chewing loudly. You couldn't look away from his lips the entire time."
    n "Gross."
    j closed "This is kinda fucked when you think about it."
    j "Sorry that sounds mean, but like why would you do a pretend date with me?"
    j "With unsolicited dating advice with it."
    j side "JJ, I uh just don't think you understand what it's like dating when you are fat."
    n "His thin body squirmed, the sharp angles of his hip bones visible through his skin."
    jjj "When you put it like that it's kinda fucked up."
    jjj "I'm not trying to pity fuck you."
    j "So what are you trying to do?"
    jjj "I dunno... normally hang out with a friend?"
    jjj "You're my friend, Jude."
    jjj "I like to suck and fuck silver foxes, and leave them wanting more."
    jjj "You deserve better than that."
    j neutral "I'm getting more grey hairs, thought you would be into that."
    n "Your laugh came out desperate."
    n "The words rancorous in your mouth, something scraped from the bottom hellscape of an incel forum."
    j "I don't need you to fuck me."
    j "I think I made my penis wrong."
    jjj "I know that, silly."
    jjj "I want to admit, if you weren't my friend I would be trying way harder to sleep with you."
    n "You saw the lies in his eyes."
    jjj "I'm so bored! You got anything to do?"
    n "Your next choice would be vital."


    menu:
        "Take him to the balcony to 'watch' the rocket launch.":
            stop music
            play music "rocket.mp3"
            j neutral "Hey."
            j smile "Want me to blow your mind?"
            jjj "I don't like that glint in your eyes."
            scene bedd with fade
            n "You gestured for him to follow you outside. The two of you walked through your bedroom and he tossed on one of your fleece jackets that was on the floor."
            show jj tsundere 
            jjj "I kinda expected it to be larger on me." 
            jjj "He let out an exaggerated pout, fidgeting noisily with the jacket."
            j neutral "It looks plenty big."
            hide jj tsundere
            show jj
            jjj "I mean you are like 6'5 right? You're a big guy Jude."
            j "You can say fat, it's not a slur."
            j "Skinny people will treat it like is one, because being fat is equivalent to being ostracized from society."
            n "Coldly, your fingers twisted around the balcony door."

            hide jj
            scene judebal with fade
            j "You ready?"
            n "In JJ palms he held a plastic baggy of kush."
            n "His eyes searched yours, pleeing for permission to use the rest."
            n "You gave a nod, and he immediately went to fetch a grinder and what was probably some wrap."
            jjjj neutral "Give me one second!"
            n "With his luck, he found what he needed in just a few seconds and scurried right back to where you were standing."
            jjjj "What did you want to show me?"
            j "Just give it a minute."
            n "A minute turned into five, echoing small talk as he rolled a pretty weak blunt."
            n "You hoped he would puff it in your face, or you could roll your own, better blunt to show off."
            j "Sorry, I kinda expected to show up sooner."
            j "It was supposed to anyways."
            jjjj "Are you talking about that fucking rocket?"
            n "The man kicked out his legs with a loud laugh, sprawling his legs carelessly."
            jjjj "You gotta stop it man."
            scene judebal2 
            n "Your fingers lifted, sparks of electricity crackling at their tips."
            n "You finally caught a faint, distant glint of it."
            n "Destruction of property was a meaningless crime, the only 'victim' was a bigoted billionaire whose rocket would’ve blown up on its own anyway."
            n "JJ stood up."
            stop music
            jjjj shock "Wait-"
            play sound "thunder.mp3"
            show screen wf(duration=1.0, fade=1.0)
            pause .5
            show judebal3
            pause 2
            n "Lightning cracked the sky,striking the rocket and spliting it clean in two."
            jjjj shockblue "Jesus fucking Christ, Jude."
            j "What? I still got it and-"
            jjjj "He was inside of that!"
            j "..."
            $ renpy.pause(1.0)
            j "You're fucking with me!"
            j "Nobody's ever been in one of those tin cans before!"
            j "What the fuck are you saying!"
            jjjj "It literally said he was inside of that thing."
            j "Fuck, man."
            pause(2.0)
            
            scene bedd with fade
            n "Everything felt sickening."
            n "Blood roared in your ears, pulsating in and out of rhythm."
            n "Why did you feel guilty over this anyways?"
            n "Perhaps the nonviolence you’d preached were just empty words"
            n "You were no saint."
            n "Your hands were soaked in blood."
            n "This wasn't your first."
            n "You prayed it was your last."
            n "An awkward, unreadable squeak escaped JJ's lips."
            n "Some sort of laugh, maybe?"
            show jj seriousblue
            jjj "Esther is going to kill you, y'know."
            n "You looked towards your monitor, the news probably already broke."
            n "No way in fuck were you ready to see everyone's reaction."
            j closed "She probably already knows it was me."
            jjj "I mean to everyone else it's a freak accident."
            j "Honestly, do you think he was even in there?"
            hide jj mad
            show jj concern
            jjj "What do you mean?"
            j concern "Those rockets explode regularly."
            j "Why would a coward like him willfully enter something that has at least a 25 percant chance of exploding?"
            hide jj concern
            show jj mad
            jjj "Because he's an idiot."
            jjj "You think his cowardice outweight his idiocy?"
            j neutral "I guess we will find out."
            window hide
            scene ENDINGR with fade
            $ renpy.pause(5.0)   
            scene black with fade
            $ renpy.pause(2.0)   
            
            return


        "Take him to the woods.":
            if good_points >= 3:
                jump cgood
            if good_points <= 3:
                jump cbad
        
    


    label wgood:
    
        j "hi"

    label wbad:
    
        j "test"

    label cgood: 
        j  j neutral "I guess we can take a walk."
        jjj "Since when where you one for walks?"
        jjj "You hardly leave your apartment!"
        j yell "I left the other night for that date!"
        jjj "And before that?"
        j neutral "Uh..."
        j "Maybe like 4 weeks ago?"
        jjj "Yeah."
        jjj "Let me grab a jacket."
        scene livingr with fade
        n "He turned and walked off toward your bedroom with a wave."
        n "Your palms began to sweat. His ass was nosey, and your room was a gallery of everything you’d ever tried to hide."
        show jjjack
        jjj "Found one! Here's one for you too."
        j concern "Where'd your pants go?"
        jjj "I don't need them."
        hide jjjack
        show jjjack yay
        j neutral "You're going to freeze your ass off!"
        n "JJ gave a little hip bump into the air."
        jjj "Nuh-uh."
        j "I don't care how fat that ass is, you are still too skinny to be doing this."
        n "JJ laughed a little too much at that comment."
        j "You ready to go?"
        hide jjjack yay
        show jjjack
        n "He offered a nod and leaned in, letting his weight settling against your shoulders. "
        n "Maybe, going outside wasn't so hard."
        scene woods with fade
        show jjjack cold
        n "You walked beside him, your steps falling into a groove."
        n "He was shivering, his skin prickled with goosebumps. Maybe going pantless had been a stupid idea. Obviously."
        n "It was an undeniable chance to make a move given to you by God."
        n "A shot so clear, that even you couldn’t possibly fuck it up."
        n "You wrapped your arm tight around his waist, pulling him closer against you."
        hide jjjack cold
        show jjjack blush
        j neutral "Sorry, I'm not very good at this. I haven't done anything properly romantic until, fuck, maybe my freshmen year of college?"
        j "There was this girl I liked. She was cute, nerdy librarian."
        j "I don't know why someone like her would like someone like me."
        jjj "And what happened?"
        j "I think she got involved with some sort of eight person polycule."
        j "Or converted to Mormonism."
        j "Whatever it was, I couldn't be there for her."
        jjj "I'm proud of you, Jude."
        j "For what?"
        jjj "You made it all the way outside, on your own suggestion!"
        j "Normal people go outside almost everyday. I feel stupid for celebrating this."
        hide jjjack blush
        show jjjack
        jjj "It's good to celebrate every new steps, though."
        jjj "You think you can make even more?"
        j "Is this your way of asking me to clean my room?"
        jjj "Maybe!~"
        j "It doesn't feel awful."
        j blush "At least, with you here."
        jjj "Mmmphmm."
        jjj "It's good seeing you. Even if I had to barge in on you."
        j "You should be glad that Andy and Dahlia warned me first."
        j "I probably would've just been in my boxers."
        j "Did you see anything in my bedroom...?"
        jjj "Oh I saw plenty!"
        jjj "Nothing surprising though."
        jjj "Actually the most surprising thing is that you had so many books."
        j "I had alot of trouble reading growing up, it feels stupid admiting that."
        j "But I was never able to focus."
        j "I do enjoy it, but I'm never able to finish a book, or a show. Anything really."
        jjj "Kind of a deal breaker for me if I'm with a guy who can't finish."
        jjj "Seriously though, I struggled with that too. I think these things do get easier though, eventually."
        j "I hope that's true."
        jjj "You'll never know if you don't try."

        jjj "Oh!"
        jjj "Look! There's a crepe stand over there."
        j blush "You're still hungry?"
        jjj "And you aren't?"
        j "No, but uh I'll get you it if you want it."
        n "Did you even have any money on you?"
        n "JJ bended over to pick over a 10 dollar bill, handing it to you."
        j neutral "How'd you know I was broke?"
        jjj "You're Jude Kriyot, when are you ever going to get a job?"
        j smile "Okay man, uh which one do you want."
        hide jjjack blush
        show jjjack cold1
        jjj "Uh... hm..."
        j side "Dubai chocolate matcha Lapupu... what the hell does that even mean?"
        j "I think I'm growing too old for this."
        hide jjjack cold1
        show jjjack blush
        jjj "That would be ideal for me!"
        j neutral "You cougar."
        hide jjjack blush
        show jjjack frown
        jjj "That's not what cougar means."
        j "Silver fox chaser?"
        hide jjjack frown 
        show jjjack 
        jjj "Can you get me the cookies and cream one with strawberries?" 
        n "You wondered if ordering this made you look like a fat ass, when in truth it was for the skinny twink beside you, whose own appetite seemed to live in his ass."
        jjj "Can you take a bite first?"
        j "Uh why?"
        jjj "I want to make sure it's not poisoned by a rival concubine, or something."
        n "You took a small, careful bite. It was far too sweet. Any more and you'd feel sick."
        j "It's fine."
        n "You handed it back and shoved your hands deep into your pockets."
        scene woods night with fade
        show jjjack cold
        jjj "It's getting dark already?"
        j neutral "Yeah... huh another full moon?"
        jjj "What's the matter?"
        j yell "It's fucking huge! And we've had a full moon for almost a week in a row."
        hide jjjack cold
        show jjjack blush
        jjj "Kinda romantic, don't you think?"
        j "No, I think it's perverted and evil."
        hide jjjack blush
        show jjjack yay 
        n "JJ laughed, but you were being completely serious."
        jjj "You don't really get it, do you?"
        j "You know I've played two games at this point where the moon gets closer in closer, and in three days it's super evil."
        n "He nuzzled his face against your side. You barely minded the crepe crumbs dusting your already stained jacket."
        n "You pressed a quick, cowardly kiss to the top of his head, then jerked back to watch for his reaction."
        hide jjjack yay
        show jjjack blush
        n "He leaned in closer. If you were braver, you’d take this as your cue to sloppily make out with him."
        n "In the woods."        
        jjj "This reminds me of something."
        j closed "I'm sorry I haven't played your yaoi games. The ones where you get chased in the woods."
        j neutral "I only know the one with the blue haired faggot, and that one scared me."
        jjj "The one I was thinking about the one with the pack of alphas that play hockey."
        j neutral "???"
        j concern "What the hell are you talking about?"
        jjj "Y'know..."
        n "He did a strange gesture, taking a bite out of his crepe."
        jjj "In omegaverse would you be an alpha, beta, or an omega?"
        j "Honestly, I would kill myself."
        hide jjjack blush
        show jjjack yay
        n "He stuck his tongue out at you, teasing pink."
        j "I mean you can explain it to me, if you want to."
        j "The hockey alpha thing."
        jjj "While I talk can you add subway surfers gameplay over it, or minecraft parkour?"
        jjj "I need constant dopamine or I will explode into a million pieces!"
        n "The two of you turned together, and headed back toward the warmth of your apartment."
        scene bedn with fade
        n "JJ propped himself at your desk and began rummaging through the drawers, hunting for any leftover weed."
        show jjjack cold1
        jjj "Is this seriously all you got?"
        n "He plopped down beside you on the thin, sorry mattress that barely qualified as a bed."
        j neutral "I haven't been out in a minute."
        j "Here, give it to me and I can roll us the last of it."
        hide jjjack cold1
        show jjjack
        jjj "I can do it too!"
        j "I mean you can, but I'm an expert."
        jjj "Okay, bluntfiend."
        scene goodend with fade
        n "Once you were done, JJ held his blunt between his teeth and leaned in close, his eyes locked on yours."
        n "You lit your own and leaned in, touching the flame to the tip of his blunt."
        n "He broke into a fit of coughing."
        n "You laid down right beside him. He rolled over onto your chest, still coughing into your shirt."
        jjj "This is so yaoiful..."
        jjj "Maybe yaoilicious."
        j "Hahaha, you still sure about the thing you said earlier?"
        jjj "Huh? What thing?"
        j "Oh, it's nothing."
        n "JJ just beamed, relaxing fully against you as he began to doze off."
        jjj "Can we do this more?"
        jjj "I like spending time with you."
        j "Yeah, as long as I don't go outside again. That moon was fucked up."
        j "If we were outside any longer I think we would've become evil perverts."
        jjj "No promises."
        n "You stroked his hair once more, tenderly. You hoped you didn’t smell too bad, and let yourself drift off to sleep."
        window hide
        scene goodjj with fade
        $ renpy.pause(5.0)   
        scene black with fade
        $ renpy.pause(2.0)   
            
        return




    label cbad: 
        stop music fadeout 0.5
        play music "mystery.mp3"
        j neutral "I guess we can take a walk..."
        jjj "Since when where you one for walks?"
        jjj "You hardly leave your apartment!"
        j yell "I left the other night for that date!"
        jjj "And before that?"
        j neutral "Uh..."
        j "Maybe like 4 weeks ago?"
        jjj "Yeah."
        jjj "Let me grab a jacket."
        scene livingr with fade
        n "He turned and walked off toward your bedroom without another word."
        n "Your palms began to sweat. His ass was nosey, and your room was a gallery of everything you’d ever tried to hide."
        show jjjack 
        jjj "Found one! Here's one for you too."
        j concern "Where'd your pants go?"
        jjj "I don't need them."
        j "But why would you-"
        j neutral "Whatever, nevermind."
        hide jjjack
        show jjjack cold1
        jjj "What was that?"
        j "Nothing."
        pause 1
        jjj "Okay."
        pause 2
        j "You ready to go?"
        n "He gave a short nod and pulled out his phone, thumbs tapping out a message to someone."
        n "You weren't mentally ready to go out of your apartment. The thought of stepping outside felt like too much."
        scene woods with fade
        n "But you trudged alongside him, watching his frosted breath."
        hide jjjack cold1
        show jjjack cold 
        n "He was shivering, his skin prickled with goosebumps. Maybe going pantless had been a stupid idea."
        n "It was an undeniable chance to make a move given to you by God."
        n "A shot so clear, that even you couldn’t possibly fuck it up."
        hide jjjack cold1
        show jjjack gross
        jjj "What are you doing?"
        j sweat "Taking off my pants."
        jjj "Why?"
        j "To give to you, you need them more than I do."
        j "See - I can self insulate, because I'm fat."
        pause 1
        jjj "Uh."
        pause .5
        jjj "You can keep those."
        n "You shimmied back into your sweatpants."
        n "He paused."
        jjj "I just... I don't understand you Jude."
        jjj "You would be alot hotter if you didn't self deprecate all the time."
        jjj "I like you, it just hurts to see how much you obviously don't."
        jjj "And then refuse to do anything about it."
        j closed "..."
        stop music fadeout 0.5
        stop music fadeout 0.5
        scene woodsdark with fade
        n "Humiliation burned like acid in your throat."
        n "The air around you grew colder by the second."
        n "As the trees twisted into gnarled, tangled hands, JJ seemed to slip away from you."
        n "You called out to him, but your voice broke, splintered in the freezing air."
        n "You fumbled in your pocket and pulled out a lighter you’d forgotten was there."
        n "The world had been shadowed by darkness."
        n "You called out for JJ again, your voice wavering."
        n "Nothing."
        play sound "wind.mp3"
        pause 5
        n "What the hell was that?"
        j yell "JJ!"
        j "JJ..."
        play music "dark.mp3"
        n "A hand crept up the crooks of your spine."
        n "Your head snapped around, but there was nothing behind you. Only an endless darkness."
        n "You ran faster and faster. God. Dates in the woods never went well for you."
        n "You could probably beat up any scary beast, if you really needed to."
        n "Your body jolted around."
        show joseph with fade
        q "Jude."
        j neutral "Oh hey Joseph, didn't expect to see you around."
        j neutral "Have you seen a twink running around? He's got no pants on and has really defining cupid bow lips."
        j "I think I fucked everything up with him."
        j "I'm such a loser."
        jf "Don't beat yourself up too hard."
        jf "You can have another date with me."
        j "Well..."
        j "I'm actually not a fan of being chased in the woods."
        jf "What? Really? I completely misread that entire situtation."
        jf "Do you want to chase me in the woods?"
        j closed "No. No chasing. I'm already out of breath."
        j neutral "Please don't take this personally, but you kinda freak me out."
        jf "Duh, that's my entire deal."
        jf "I'm Joseph the Flasher, I Joseph the Flash people."
        j "He totally ditched me, didn't he."
        j "I feel so stupid. I know I fumbled bad."
        jf "Deep down we are all evil perverts and transgender."
        jf "The issue is you haven't embraced that. That's why the twink left you."
        j "I don't like to think myself as evil."
        j "Or a pervert."
        j "Actually, I think you're full of shit."
        jf "I'm going to Joseph the Flash YOU NOW!"
        n "Without another word, he threw a handful of sand directly into your eyes, blinding you."
        stop sound
        play sound "bell.mp3"
        show screen wf(duration=1.0, fade=1.0)
        pause .5
        scene bedn
        pause 2 
        stop music fadeout 1
        n "Blood pulsated in your ears loudly before turning to a scream."
        n "You were back at your own desk, the familiar mess suddenly alien and strange in the dim light."
        n "The monitor's screen flashed with a message."
        jj neutral "Hey, that was a pretty shitty date."
        bf neutral "Sorry."
        bf neutral "I think I blacked out sometime after I tried taking off my pants."
        bf "I can make up it up to you."
        jj "I'm glad you're okay."
        jj "To be honest I can't remember much either."
        jj "But yeah, we can hang out another time."
        bf neutral "Good."
        n "The monitor screen seemed to shut off."
        show screen ft(duration=0.5, fade=1.0)
        scene bedn
        play sound "scarypiano.mp3"
        pause 2.0
        
        j closed "Hey man, I think you may have a rash."
        j neutral "Those nipples don't look normal. You might want to see a doctor about that."
        j "Maybe they should call you Joseph the Rash...er"
        show joseph
        jf "Oh yeah, maybe."
        j "I forgot to lock the door, again."
        jf "I don't know, I just opened a portal"
        j "Can you just like... close it?"
        jf "Just give me a minute."
        j "Uh, bye I guess. Please don't come back."
        jf "I think I need to work on my social cues."
        j "I know I need to."
        j "Bye."
        jf "Byeeeee!"
        hide joseph
        n "It was too quiet, it gave you time to replay every choice you could have made differently."
        window hide
        scene badend with fade
        $ renpy.pause(6.0)
        show screen bf(duration=2.0, fade=2.0)
        $ renpy.pause(1.0)
        return


    # This ends the game.

    return
